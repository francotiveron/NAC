﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static Nac.Field.Citect.CtApi;

namespace Nac.Field.Citect {
    public class NacFieldCitectProxy {
        private const string cLoopback = "127.0.0.1";
        private string _address, _user, _password;
        private uint _hCtApi = 0;

        public NacFieldCitectProxy(string user, string password, string address = cLoopback) {
            _address = address;
            _user = user;
            _password = password;
        }

        ~NacFieldCitectProxy() {
            if (_hCtApi != 0) ctClose(_hCtApi);
            _hCtApi = 0;
        }
        private uint Conn {
            get {
                if (_hCtApi == 0) _hCtApi = ctOpen(_address, _user, _password, CT_OPEN_RECONNECT);
                return _hCtApi;
            }
        }
        public bool Read(string name, out string sValue) {
            StringBuilder sb = new StringBuilder(100);

            bool readOK = ctTagRead(Conn, name, sb, sb.Capacity);
            sValue = readOK ? sb.ToString() : "?";
            return readOK;
        }

        public bool Read(string[] names, out string[] sValues) {
            bool readOK = false;

            sValues = names.Select(name => {
                string sValue;
                readOK |= Read(name, out sValue);
                return sValue;
            }).ToArray();

            return readOK;
        }

        public bool Read1(string[] names, out string[] sValues) {
            var hList = ctListNew(Conn, 0/*, CT_LIST_EVENT_NEW | CT_LIST_EVENT_STATUS*/);
            var hTags = names.Foreach(name => ctListAdd(hList, name));

            bool readOK = ctListRead(hList, null);
            if (!readOK) {
                int error = System.Runtime.InteropServices.Marshal.GetLastWin32Error();
                Debug.Print($"ctListRead={error}");
            }

            if (readOK) {
                StringBuilder sb = new StringBuilder(100);
                sValues = hTags.Select(hTag => {
                    bool tagOK = ctListData(hTag, sb, sb.Capacity, 0);
                    if (!tagOK) {
                        int error = System.Runtime.InteropServices.Marshal.GetLastWin32Error();
                        Debug.Print($"ctListDataError={error}");
                    }
                    return tagOK ? sb.ToString() : "?";
                }).ToArray();
            } else sValues = null;

            ctListFree(hList);

            return readOK;
        }
        public bool Write(string name, string sValue) {
            bool writeOK = ctTagWrite(Conn, name, sValue);
            return writeOK;
        }

        private string[] _citectTypes = { "Digital", "Integer", "Real", "BCD", "Long", "Long BCD", "Long Real", "String", "Byte", "Void", "Unsigned integer" };
 
        public string[] Browse(string filter) {
            uint hObj = 0;
            uint hFind = ctFindFirst(Conn, "TAG", filter, ref hObj, 0);
            List<string> result = new List<string>();

            if (hFind != 0 && hObj != 0) {
                int len = 32, nTags = 0;
                StringBuilder sb = new StringBuilder(len);

                do {
                    if (ctGetProperty(hObj, "TAG", sb, sb.Capacity, ref len, DBTYPEENUM.DBTYPE_STR)) {
                        var name = sb.ToString();
                        ctGetProperty(hObj, "TYPE", sb, sb.Capacity, ref len, DBTYPEENUM.DBTYPE_STR);
                        int typeIndex; bool indexValid = int.TryParse(sb.ToString(), out typeIndex);
                        var type = indexValid && typeIndex >= 0 && typeIndex <= _citectTypes.Length ? _citectTypes[typeIndex] : "???";
                        result.Add($"{name},{type}");
                        ++nTags;
                    }
                }
                while (ctFindNext(hFind, ref hObj) && nTags < 1000);
                ctFindClose(hFind);
            }
            return result.ToArray();
        }
    }
}
