﻿using Nac.Field.Citect;

public interface INacFieldCitectContext {
    NacFieldCitectProxy Citect { get; }
}

public static class NacFieldCitectGlobal {
    public static INacFieldCitectContext G { get; set; }
}

namespace Nac.Field.Citect {
    using static NacFieldCitectGlobal;

    public class NacFieldCitectContext : INacFieldCitectContext {
        private const string cCitectUser = "Administrator";
        private const string cCitectPassword = "alfa1";

        #region static
        private static NacFieldCitectContext Instance { get { return G as NacFieldCitectContext; } }
        public static void Init() {
            G = new NacFieldCitectContext();
            Instance.Citect = new NacFieldCitectProxy(cCitectUser, cCitectPassword);
        }
        public static void Dispose() {
        }
        #endregion

        public NacFieldCitectProxy Citect { get; private set; }
    }
}
